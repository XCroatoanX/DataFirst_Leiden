var correctCode = "1234";

function checkCode() {
    var enteredCode = document.getElementById("code").value;

    if  (enteredCode === correctCode) {
        alert("Inloggen gelukt!");
        window.location.href = "index.html";
    } else {
        alert("Inloggen mislukt. Voer een geldige 4-cijferige code in.");
    }
}