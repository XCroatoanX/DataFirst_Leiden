setTimeout(function () {
  window.location.href = "/artem_web/html/login.html";
}, 5000);
